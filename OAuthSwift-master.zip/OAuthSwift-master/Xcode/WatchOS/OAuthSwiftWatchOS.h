//
//  OAuthSwiftWatchOS.h
//  OAuthSwiftWatchOS
//
//  Created by phimage on 04/12/15.
//  Copyright © 2015 Dongri Jin. All rights reserved.
//

#import <WatchKit/WatchKit.h>

//! Project version number for OAuthSwiftWatchOS.
FOUNDATION_EXPORT double OAuthSwiftWatchOSVersionNumber;

//! Project version string for OAuthSwiftWatchOS.
FOUNDATION_EXPORT const unsigned char OAuthSwiftWatchOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OAuthSwiftWatchOS/PublicHeader.h>


