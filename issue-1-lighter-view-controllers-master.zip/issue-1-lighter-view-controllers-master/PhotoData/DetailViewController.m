//
//  DetailViewController.m
//  objc.io example project (issue #1)
//


#import "DetailViewController.h"


@implementation DetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = self.key;
}

@end
