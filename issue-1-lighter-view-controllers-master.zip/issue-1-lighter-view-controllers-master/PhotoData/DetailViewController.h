//
//  DetailViewController.h
//  objc.io example project (issue #1)
//


#import <Foundation/Foundation.h>


@interface DetailViewController : UIViewController

@property (nonatomic, strong) NSString *key;

@end