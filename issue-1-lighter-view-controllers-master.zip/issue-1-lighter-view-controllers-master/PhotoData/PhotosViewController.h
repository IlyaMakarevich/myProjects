//
//  PhotosViewController.h
//  objc.io example project (issue #1)
//

#import <UIKit/UIKit.h>


@interface PhotosViewController : UITableViewController

@end
