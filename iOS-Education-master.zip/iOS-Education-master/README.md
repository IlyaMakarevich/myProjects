# iOS-Education
Some tasks for trainee iOS developers
