//
//  TwitterLoginDelegate.swift
//  TwitterTest
//
//  Created by Константин on 21.03.16.
//  Copyright © 2016 Константин. All rights reserved.
//

import UIKit

protocol TwitterLoginDelegate: class {
    func continueLogin()
}