//
//  ProfileViewController.swift
//  TwitterTest
//
//  Created by Константин on 05.04.16.
//  Copyright © 2016 Константин. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
