//
//  AppDelegate.swift
//  TwitterApi
//
//  Created by Dogukan Tizer on 01.10.19.
//  Copyright © 2019 Dogukan Tizer. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        return true
    }
    
}
