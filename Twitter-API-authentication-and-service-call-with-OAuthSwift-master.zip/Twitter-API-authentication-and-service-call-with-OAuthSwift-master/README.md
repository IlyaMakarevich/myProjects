# Twitter-API-authentication-and-service-call-with-OAuthSwift
An ios swift project that provides Twitter API authentication and rest api call with OAuthSwift

Tutorial: https://www.mobiler.dev/post/oauthswift-ile-twitter-api-kullanimi

Demo Video: https://www.youtube.com/watch?v=u8GRxaRddGo&feature=emb_title


![Design](https://static.wixstatic.com/media/a27d24_33521dedf4fe4f5cba0de72a8e06d5ec~mv2.png/v1/fill/w_608,h_1104,al_c/a27d24_33521dedf4fe4f5cba0de72a8e06d5ec~mv2.png)


![Demo View](https://static.wixstatic.com/media/a27d24_d25d7ff6f2294d04b19f4a5642c8f1d8~mv2.png/v1/fill/w_556,h_1110,al_c/a27d24_d25d7ff6f2294d04b19f4a5642c8f1d8~mv2.png)
