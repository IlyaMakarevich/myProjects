//
//  SearchViewControlla.h
//  Nebulous
//
//  Created by Elyanil Liranzo Castro on 5/11/17.
//  Copyright © 2017 Elyanil Liranzo Castro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchViewControlla : UIViewController
@property(strong, nonatomic) NSMutableArray *searchResults;
@end
