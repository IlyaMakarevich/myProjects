#import "Rat.h"


@interface SneakyRat : NSObject <Rat>

@end
