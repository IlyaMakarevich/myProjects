#import "SneakyRat.h"


@implementation SneakyRat

#pragma mark - <Rat>

- (NSString *)squeak
{
    return @"Squeak Squeak!!!\n";
}

- (NSString *)runAround
{
    return @"Run around really fast...\n";
}

- (NSString *)swim
{
    return @"Splash, rat paddle...\n";
}

- (NSString *)flyWithSuperFlightSuit
{
    return @"Equips high powered super technological advanced wings and soars through the sky...\n";
}

@end
