

@protocol Rat <NSObject>

- (NSString *)squeak;
- (NSString *)runAround;
- (NSString *)swim;
- (NSString *)flyWithSuperFlightSuit;
   
@end