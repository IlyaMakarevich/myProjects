#import "Duck.h"


@interface CrestedDuck : NSObject <Duck>

@end
