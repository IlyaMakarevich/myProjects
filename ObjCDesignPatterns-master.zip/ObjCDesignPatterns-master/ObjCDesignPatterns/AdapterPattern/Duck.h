

@protocol Duck <NSObject>

- (NSString *)quack;
- (NSString *)walk;
- (NSString *)swim;
- (NSString *)fly;

@end
