#import "Beverage.h"


@interface CabernetSauvignon : Beverage

@end
