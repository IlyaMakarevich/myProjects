#import "Beverage.h"


@interface Chardonnay : Beverage

@end
