#import "Beverage.h"


@interface Merlot : Beverage

@end
