#import "Beverage.h"


@interface JagerBomb : Beverage

@end
