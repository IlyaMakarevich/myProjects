#import "Bar.h"
#import "Beverage.h"


@interface Lager : Beverage

@end
