#import "Bar.h"


@interface WineBar : Bar

@end
