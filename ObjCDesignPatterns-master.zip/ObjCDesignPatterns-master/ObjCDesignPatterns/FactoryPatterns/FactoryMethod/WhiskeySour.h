#import "Beverage.h"


@interface WhiskeySour : Beverage

@end
