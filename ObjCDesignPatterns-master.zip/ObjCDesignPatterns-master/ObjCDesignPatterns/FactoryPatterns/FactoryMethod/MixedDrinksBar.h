#import "Bar.h"


@interface MixedDrinksBar : Bar

@end
