#import "Beverage.h"


@interface RumAndCoke : Beverage

@end
