#import "Beverage.h"


@interface Stout : Beverage

@end
