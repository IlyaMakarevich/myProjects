#import "Beverage.h"


@interface Ale : Beverage

@end
