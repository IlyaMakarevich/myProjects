#import "Bar.h"


@interface BeerBar : Bar

@end
