#import "TacoStore.h"


@interface StreetTacoStore : TacoStore

@end
