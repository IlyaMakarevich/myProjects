#import "TacoContentsFactory.h"


@interface CrunchyTacoContentsFactory : NSObject <TacoContentsFactory>

@end
