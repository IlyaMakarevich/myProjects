#import "Guacamole.h"


@implementation Guacamole

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Guacamole";
    }
    return self;
}

@end
