#import "Beef.h"


@interface Molida : Beef

@end
