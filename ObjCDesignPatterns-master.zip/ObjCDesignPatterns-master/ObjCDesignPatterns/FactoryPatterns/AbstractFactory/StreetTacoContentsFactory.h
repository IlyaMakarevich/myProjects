#import "TacoContentsFactory.h"


@interface StreetTacoContentsFactory : NSObject <TacoContentsFactory>

@end
