

@interface Extra : NSObject

@property (strong, nonatomic) NSString *name;

@end
