#import "Tortilla.h"


@interface Maiz : Tortilla

@end
