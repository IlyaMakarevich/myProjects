#import "Picante.h"


@implementation Picante

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Picante";
    }
    return self;
}

@end
