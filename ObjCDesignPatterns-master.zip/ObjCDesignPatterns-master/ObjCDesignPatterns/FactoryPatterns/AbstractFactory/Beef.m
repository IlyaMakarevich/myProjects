#import "Beef.h"


@implementation Beef

@end
