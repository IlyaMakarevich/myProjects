#import "Mild.h"


@implementation Mild

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Mild";
    }
    return self;
}

@end
