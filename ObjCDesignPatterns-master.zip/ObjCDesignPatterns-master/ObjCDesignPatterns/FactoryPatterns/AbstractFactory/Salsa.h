

@interface Salsa : NSObject

@property (strong, nonatomic) NSString *name;

@end
