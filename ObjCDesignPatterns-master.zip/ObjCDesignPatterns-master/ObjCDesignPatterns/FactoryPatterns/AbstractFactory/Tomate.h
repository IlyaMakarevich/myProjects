#import "Vedura.h"


@interface Tomate : Vedura

@end
