#import "Queso.h"


@interface Cheddar : Queso

@end
