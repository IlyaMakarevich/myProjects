#import "Fresco.h"


@implementation Fresco

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Fresco";
    }
    return self;
}

@end
