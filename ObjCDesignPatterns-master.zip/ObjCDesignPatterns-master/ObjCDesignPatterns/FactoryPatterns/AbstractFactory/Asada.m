#import "Asada.h"


@implementation Asada

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Asada";
    }
    return self;
}

@end
