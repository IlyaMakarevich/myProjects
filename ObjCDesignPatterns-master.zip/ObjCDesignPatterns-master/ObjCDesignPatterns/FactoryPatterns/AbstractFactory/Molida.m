#import "Molida.h"


@implementation Molida

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Molida";
    }
    return self;
}

@end
