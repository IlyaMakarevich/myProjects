#import "Cheddar.h"


@implementation Cheddar

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Cheddar";
    }
    return self;
}

@end
