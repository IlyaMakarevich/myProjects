#import "Cebolla.h"


@implementation Cebolla

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Cebolla";
    }
    return self;
}

@end
