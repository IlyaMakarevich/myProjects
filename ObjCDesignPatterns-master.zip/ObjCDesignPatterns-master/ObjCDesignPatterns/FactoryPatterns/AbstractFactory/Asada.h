#import "Beef.h"


@interface Asada : Beef

@end
