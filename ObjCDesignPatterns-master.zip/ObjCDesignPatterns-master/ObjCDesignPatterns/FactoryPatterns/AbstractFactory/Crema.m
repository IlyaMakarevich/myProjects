#import "Crema.h"


@implementation Crema

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Crema";
    }
    return self;
}

@end
