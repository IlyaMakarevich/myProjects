#import "Maiz.h"


@implementation Maiz

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Maiz";
    }
    return self;
}

@end
