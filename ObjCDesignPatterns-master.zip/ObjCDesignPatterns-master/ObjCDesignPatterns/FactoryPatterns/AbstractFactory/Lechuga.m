#import "Lechuga.h"


@implementation Lechuga

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Lechuga";
    }
    return self;
}

@end
