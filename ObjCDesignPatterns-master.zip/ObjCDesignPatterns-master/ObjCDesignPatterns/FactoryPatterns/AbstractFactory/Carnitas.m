#import "Carnitas.h"


@implementation Carnitas

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Carnitas";
    }
    return self;
}

@end
