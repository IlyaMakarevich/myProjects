#import "Vedura.h"


@interface Cebolla : Vedura

@end
