#import "Pork.h"


@interface Carnitas : Pork

@end
