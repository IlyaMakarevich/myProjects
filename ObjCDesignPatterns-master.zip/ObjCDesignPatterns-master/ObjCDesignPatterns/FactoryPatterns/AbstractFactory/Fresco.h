#import "Queso.h"


@interface Fresco : Queso

@end
