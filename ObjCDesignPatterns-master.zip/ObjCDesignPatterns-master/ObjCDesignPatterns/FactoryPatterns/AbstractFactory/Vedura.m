#import "Vedura.h"


@implementation Vedura

@end
