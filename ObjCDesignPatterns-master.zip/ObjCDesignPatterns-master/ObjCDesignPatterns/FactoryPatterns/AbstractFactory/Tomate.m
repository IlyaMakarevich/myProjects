#import "Tomate.h"


@implementation Tomate

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Tomate";
    }
    return self;
}

@end
