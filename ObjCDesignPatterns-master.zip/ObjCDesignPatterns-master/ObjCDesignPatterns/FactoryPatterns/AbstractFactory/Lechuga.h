#import "Vedura.h"


@interface Lechuga : Vedura

@end
