#import "Taco.h"


@implementation Taco

#pragma mark - Public Methods

- (void)prepare
{
    NSLog(@"Preparing taco...");
}

- (void)loadUpIngredients
{
    NSLog(@"Loading up all taco ingredients...");
}

- (void)wrap
{
    NSLog(@"Wrapping up the taco!!!");
}

@end
