#import "Cilantro.h"


@implementation Cilantro

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Cilantro";
    }
    return self;
}

@end
