#import "ChileVerde.h"


@implementation ChileVerde

#pragma mark - Init Methods

- (id)init
{
    self = [super init];
    if (self) {
        self.name = @"Chile Verde";
    }
    return self;
}

@end
