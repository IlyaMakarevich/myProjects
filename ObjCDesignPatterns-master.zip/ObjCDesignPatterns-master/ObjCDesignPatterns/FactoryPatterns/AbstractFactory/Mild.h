#import "Salsa.h"


@interface Mild : Salsa

@end
