#import "Salsa.h"


@interface Picante : Salsa

@end
