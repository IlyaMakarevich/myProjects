

@interface Tortilla : NSObject

@property (strong, nonatomic) NSString *name;

@end
