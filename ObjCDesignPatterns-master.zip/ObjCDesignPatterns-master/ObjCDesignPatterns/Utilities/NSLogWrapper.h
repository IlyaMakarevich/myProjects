

@interface NSLogWrapper : NSObject

- (void)log:(NSString *)logMessage;

@end
