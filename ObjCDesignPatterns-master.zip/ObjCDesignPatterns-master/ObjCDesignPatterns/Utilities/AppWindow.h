

@interface AppWindow : NSObject

- (void)initializeWithRootViewController:(UIViewController *)rootViewController;

@end
