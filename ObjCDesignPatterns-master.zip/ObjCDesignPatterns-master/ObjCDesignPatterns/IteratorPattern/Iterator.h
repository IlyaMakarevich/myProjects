

@protocol Iterator <NSObject>

- (id)next;
- (BOOL)hasNext;

@end
