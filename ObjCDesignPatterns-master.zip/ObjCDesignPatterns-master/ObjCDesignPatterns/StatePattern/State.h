

@protocol State <NSObject>

- (NSString *)insertCoin;
- (NSString *)pressStart;
- (NSString *)playGame;

@end
