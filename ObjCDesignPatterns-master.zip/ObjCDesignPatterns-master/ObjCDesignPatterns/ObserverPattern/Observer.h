

@protocol Observer <NSObject>

- (void)update:(NSString *)updateText;

@end
