#import "NewsReporter.h"


@interface BurritoReporter : NSObject <NewsReporter>

@property (strong, nonatomic) NSString *headline;

@end
