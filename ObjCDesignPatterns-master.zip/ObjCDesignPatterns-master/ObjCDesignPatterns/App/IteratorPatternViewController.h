#import <UIKit/UIKit.h>


@interface IteratorPatternViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
