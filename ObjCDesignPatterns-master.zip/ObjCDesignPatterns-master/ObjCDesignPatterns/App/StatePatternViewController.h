#import <UIKit/UIKit.h>


@interface StatePatternViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
