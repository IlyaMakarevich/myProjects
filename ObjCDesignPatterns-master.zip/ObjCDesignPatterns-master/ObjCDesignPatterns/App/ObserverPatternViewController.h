#import <UIKit/UIKit.h>


@interface ObserverPatternViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
