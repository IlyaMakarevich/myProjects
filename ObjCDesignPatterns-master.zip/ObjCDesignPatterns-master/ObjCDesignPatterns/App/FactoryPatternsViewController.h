#import <UIKit/UIKit.h>


@interface FactoryPatternsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
