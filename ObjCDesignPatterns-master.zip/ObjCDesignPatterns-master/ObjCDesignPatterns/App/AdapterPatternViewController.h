#import <UIKit/UIKit.h>


@interface AdapterPatternViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
