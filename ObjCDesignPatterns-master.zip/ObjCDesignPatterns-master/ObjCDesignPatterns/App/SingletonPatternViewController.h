#import <UIKit/UIKit.h>


@interface SingletonPatternViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
