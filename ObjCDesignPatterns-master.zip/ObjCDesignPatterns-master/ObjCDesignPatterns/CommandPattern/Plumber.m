#import "Plumber.h"


@implementation Plumber

#pragma mark - Public Methods

- (NSString *)fixLeak
{
    return @"Plumber fixed leak!";
}

- (NSString *)unclogDrain
{
    return @"Plumber unclogged drain!";
}

@end
