#import <UIKit/UIKit.h>


@interface CommandPatternViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *textView;

@end
