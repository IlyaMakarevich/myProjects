#import "Exterminator.h"


@implementation Exterminator

#pragma mark - Public Methods

- (NSString *)killRoaches
{
    return @"Exterminator killed roaches!";
}

- (NSString *)captureRats
{
    return @"Exterminator captured rats!";
}

@end
