#import "Gardener.h"


@implementation Gardener

#pragma mark - Public Methods

- (NSString *)plantRoses
{
    return @"Gardener planted roses!";
}

- (NSString *)trimBushes
{
    return @"Gardener trimmed bushes!";
}

@end
