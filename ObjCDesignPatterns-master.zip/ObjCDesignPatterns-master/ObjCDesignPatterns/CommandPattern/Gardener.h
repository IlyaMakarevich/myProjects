

@interface Gardener : NSObject

- (NSString *)plantRoses;
- (NSString *)trimBushes;

@end
