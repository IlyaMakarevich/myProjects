

@interface Exterminator : NSObject

- (NSString *)killRoaches;
- (NSString *)captureRats;

@end
