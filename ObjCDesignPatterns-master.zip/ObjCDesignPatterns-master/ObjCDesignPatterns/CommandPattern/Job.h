

@protocol Job <NSObject>

- (NSString *)execute;

@end
