

@interface Plumber : NSObject

- (NSString *)fixLeak;
- (NSString *)unclogDrain;

@end
