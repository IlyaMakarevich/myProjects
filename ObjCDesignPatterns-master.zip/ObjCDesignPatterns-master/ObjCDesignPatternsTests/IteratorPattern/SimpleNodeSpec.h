//
//  SimpleNodeSpec.h
//  ObjCDesignPatterns
//
//  Created by Baumbud on 10/12/13.
//  Copyright (c) 2013 RKB Designs. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SimpleNodeSpec : NSObject

@end
